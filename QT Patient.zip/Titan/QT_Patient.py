from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication,QMessageBox,QTableWidgetItem
from pickle import load,dump
from random import randint
from numpy import array
from datetime import datetime

def b1_click():
    add.show()
    add.addp.clicked.connect ( ADD )
def b2_click():
    modify.show()
    # print("before clicked")
    modify.modif.clicked.connect ( modif_click )
    # print("out clicked")
    
def  modif_click():
    # print("in clicked")
    if(exist("C:/Titan/patient.dat",modify.codec.text())):
        addModify.show()
        addModify.modif2.clicked.connect ( MODIFY )
        # print("modified")
    else:
        QMessageBox.critical(modify,"error","!code was not found!")


def b3_click():
    search.show()
    search.b41.clicked.connect( lambda : SEARCH("name") )
    search.ex.clicked.connect(lambda : EXPORTATION("name"))

def b4_click():
    DELETE()
def b5_click():
    ORDER()
def b6_click():
    export.show()
    export.ex.clicked.connect(lambda : EXPORTATION("date") )
    export.b41.clicked.connect(lambda : SEARCH("date") )
def b7_click():
    show.show()
    SHOW()
    show.reload.clicked.connect (SHOW)
def b8_click():
    windows.close()

def ADD():
    F=open("C:/Titan/patient.dat","ab")
    e={}
    test=True
    e["name"]=add.name.text()
    if not(alpha(e['name'])):
        QMessageBox.critical(add,"error","!name invalid!")
        test=False
        
    e["familyName"]=add.lname.text()
    if not(alpha(e['familyName'])):
        QMessageBox.critical(add,"error","!!family name invalid!!")
        test=False

        
    code=add.code.text()
    if not(code!="0" and code.isdecimal() and not exist("C:/Titan/patient.dat",code)):
        QMessageBox.critical(add,"error","!code invalid!")
        test=False
    if test :
        e['code']=int(code)
        e["dateOfLastVisite"],test=dating(test)
    if test :
        dump(e,F)
        QMessageBox.information(add,"done","patient added successfully")
 
    F.close()

def alpha(ch):
# verifie if a string contains only minuscule letters
    test=True
    for i in range(len(ch)):
        if not("a"<=ch[i]<="z"):
            test=False
    return test
    
def MODIFY():
    F=open("C:/Titan/patient.dat","rb")
    T=array([dict()]*10000)
    test=True
    found=False
    n=0
    while(test==True):
        try:
            e=load(F)
            T[n]=e
            n=n+1
        except:
            test=False

    if (modify.codec.text().isdecimal):
        code=int(modify.codec.text())
        found=False
        for i in range(n):
            if(T[i]["code"]==code):
                found=True
                j=i

    F.close()
    

    if(found):
        test=True
        e["name"]=addModify.name2.text()
        if not(alpha(e['name'])):
            QMessageBox.critical(add,"error","!name invalid!")
            test=False
            
        e["familyName"]=addModify.lname2.text()
        if not(alpha(e['familyName'])):
            QMessageBox.critical(addModify,"error","!!family name invalid!!")
            test=False

            
        code=addModify.code2.text()
        if not(code!="0" and code.isdecimal() and ((not exist("C:/Titan/patient.dat",code)) or modify.codec.text()==code) ):
            QMessageBox.critical(addModify,"error","!code invalid!")
            test=False
        if test :
            e['code']=int(code)
            e["dateOfLastVisite"],test=dating2(test)
        if test :
            T[j]=e
            QMessageBox.information(addModify,"done","patient updated successfully")
            addModify.close()
            modify.close()

    F=open("C:/Titan/patient.dat","wb")
    for i in range(n):
        dump(T[i],F)
    F.close()
    print("after update")


def SEARCH(mode):
    if (mode=="name"):
        search.patients2.setRowCount(0)
    elif (mode=="date"):
        export.patients2.setRowCount(0)
    F=open("C:/Titan/patient.dat","rb")
    name=search.search.text()
    test=True
    i=0
    while(test==True):
        try:
            e=load(F)
            if (mode=="name"):
                if(search.search.text()==e["name"]):
                    search.patients2.insertRow(i)
                    search.patients2.setItem(i,0,QTableWidgetItem(e["name"]))
                    search.patients2.setItem(i,1,QTableWidgetItem(e["familyName"]))
                    search.patients2.setItem(i,2,QTableWidgetItem(str(e["code"])))
                    vdate=str(e["dateOfLastVisite"]["year"])+"/"+ str(e["dateOfLastVisite"]["month"]) + "/"+ str(e["dateOfLastVisite"]["day"])
                    search.patients2.setItem(i,3,QTableWidgetItem(vdate))
            elif(mode=="date"):
                if(str(e["dateOfLastVisite"]["year"])==export.yex.text() and str(e["dateOfLastVisite"]["month"])==export.mex.text()):
                    export.patients2.insertRow(i)
                    export.patients2.setItem(i,0,QTableWidgetItem(e["name"]))
                    export.patients2.setItem(i,1,QTableWidgetItem(e["familyName"]))
                    export.patients2.setItem(i,2,QTableWidgetItem(str(e["code"])))
                    vdate=str(e["dateOfLastVisite"]["year"])+"/"+ str(e["dateOfLastVisite"]["month"]) + "/"+ str(e["dateOfLastVisite"]["day"])
                    export.patients2.setItem(i,3,QTableWidgetItem(vdate))

        except:
            test=False
    F.close()
    

def DELETE():
    F=open("C:/Titan/patient.dat","rb")
    T=array([dict()]*10000)
    test=True
    tst=False
    n=0
    while(test):
        try:
            e=load(F)
            if (datetime.now().year-e["dateOfLastVisite"]["year"]<=10):
                T[n]=e
                n=n+1
            else:
                print("deleted a patient")
                tst=True
            
        except:
            test=False
    
    F.close()
    F=open("C:/Titan/patient.dat","wb")
    for i in range(n):
        dump(T[i],F)
    F.close()
    
    if(tst):
        QMessageBox.information(windows,"done","we deleted someone")
    else:
        QMessageBox.information(windows,"done","no one was deleted")
        
def ORDER():
    F=open("C:/Titan/patient.dat","rb")
    T=array([dict()]*10000)
    test=True
    n=0
    while(test==True):
        try:
            e=load(F)
            T[n]=e
            n=n+1
            
        except:
            test=False
    F.close()
    
    tri(T,n)
    
    F=open("C:/Titan/patient.dat","wb")
    for i in range(n):
        dump(T[i],F)
    F.close()
    QMessageBox.information(windows,"done","database ordered succesfully")

def tri(T,n):
    test=True
    while(test):
        test=False
        for i in range (n-1):
            if (T[i]["code"]<T[i+1]["code"]):
                e=T[i]
                T[i]=T[i+1]
                T[i+1]=e
                test=True


def EXPORTATION(mode):
    F=open("C:/Titan/patient.dat","rb")
    if (mode=="name"):
        FT=open("C:/Titan/exportedPatientsByName.txt","w")
    elif (mode=="date"):
        FT=open("C:/Titan/exportedPatientsByDate.txt","w")
    T=array([dict()]*10000)
    test=True
    n=0
    while(test==True):
        try:
            e=load(F)
            if (mode=="name"):
                if(search.search.text()==e["name"]):
                    ch=str(e["name"])+"*"+str(e["familyName"])+"*"+str(e["code"])+"*"+str(e["dateOfLastVisite"]["day"])+"/"+str(e["dateOfLastVisite"]["month"])+"/"+str(e["dateOfLastVisite"]["year"])
                    FT.write(ch+"\n")
            elif (mode=="date"):
                if(str(e["dateOfLastVisite"]["year"])==export.yex.text() and str(e["dateOfLastVisite"]["month"])==export.mex.text()):
                    ch=str(e["name"])+"*"+str(e["familyName"])+"*"+str(e["code"])+"*"+str(e["dateOfLastVisite"]["day"])+"/"+str(e["dateOfLastVisite"]["month"])+"/"+str(e["dateOfLastVisite"]["year"])
                    FT.write(ch+"\n")
        except:
            test=False
    F.close()
    
def SHOW():
    show.patients.setRowCount(0)
    F=open("C:/Titan/patient.dat","rb")
    
    test=True
    i=0
    while(test):
        try:
            e=load(F)
            show.patients.insertRow(i)
            show.patients.setItem(i,0,QTableWidgetItem(e["name"]))
            show.patients.setItem(i,1,QTableWidgetItem(e["familyName"]))
            show.patients.setItem(i,2,QTableWidgetItem(str(e["code"])))
            vdate=str(e["dateOfLastVisite"]["year"])+"/"+ str(e["dateOfLastVisite"]["month"]) + "/"+ str(e["dateOfLastVisite"]["day"])
            show.patients.setItem(i,3,QTableWidgetItem(vdate))
        except:
            test=False
    F.close()
    
def exist(path,code):
    F=open(path,"rb")
    test=True
    exist=False
    while(test):
        try:
            e=load(F)
            if (code.isdecimal()):
                if (e["code"]==int(code)):
                    exist=True
        except:
            test=False
    return exist
    F.close()

def dating(test):
    e={}
    if (add.y.text().isdecimal()):
        e["year"]=int(add.y.text())
    else:
        e["year"]=0
    if not(2000<=e["year"]):
        QMessageBox.critical(add,"error","!year invalid!")
        test=False
    
    if (add.m.text().isdecimal()):
        e["month"]=int(add.m.text())
    else:
        e["month"]=0
    if not(1<=e["month"]<=12):
        QMessageBox.critical(add,"error","!month invalid!")
        test=False

    b=-1
    if (e["month"]==2):
        if(e["year"]%4==0):
            b=29
        else:
            b=28
    elif(e["month"] in {4,6,9,11}):
        b=30
    elif(e["month"] in {1,3,5,7,8,10,12}):
        b=31

    if (add.d.text().isdecimal()):
        e["day"]=int(add.d.text())
    else:
        e["day"]=0
    if not(1<=e["day"]<=b):
        QMessageBox.critical(add,"error","!day invalid!")
        test=False
    return e,test

def dating2(test):
    e={}
    if (addModify.y2.text().isdecimal()):
        e["year"]=int(addModify.y2.text())
    else:
        e["year"]=0
    if not(2000<=e["year"]):
        QMessageBox.critical(addModify,"error","!year invalid!")
        test=False
    
    if (addModify.m2.text().isdecimal()):
        e["month"]=int(addModify.m2.text())
    else:
        e["month"]=0
    if not(1<=e["month"]<=12):
        QMessageBox.critical(addModify,"error","!month invalid!")
        test=False

    b=0
    if (e["month"]==2):
        if(e["year"]%4==0):
            b=29
        else:
            b=28
    elif(e["month"] in {4,6,9,11}):
        b=30
    elif(e["month"] in {1,3,5,7,8,10,12}):
        b=31

    if (addModify.d2.text().isdecimal()):
        e["day"]=int(addModify.d2.text())
    else:
        e["day"]=0
    if not(1<=e["day"]<=b):
        QMessageBox.critical(addModify,"error","!day invalid!")
        test=False
    return e,test

app = QApplication([])
windows = loadUi ("C:/Titan/project.ui")
add = loadUi ("C:/Titan/add.ui")
search = loadUi ("C:/Titan/search.ui")
modify = loadUi ("C:/Titan/modify.ui")
addModify = loadUi ("C:/Titan/modify_add.ui")
show = loadUi ("C:/Titan/show.ui")
export = loadUi ("C:/Titan/export.ui")

windows.show()
windows.b1.clicked.connect ( b1_click )
windows.b2.clicked.connect ( b2_click )
windows.b3.clicked.connect ( b3_click )
windows.b4.clicked.connect ( b4_click )
windows.b5.clicked.connect ( b5_click )
windows.b6.clicked.connect ( b6_click )
windows.b7.clicked.connect ( b7_click )
windows.b8.clicked.connect ( b8_click )

app.exec_()
